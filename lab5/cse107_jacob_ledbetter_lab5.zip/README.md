# Readme for lab5 for cse107

Purpose:
Cipher:
Preforms a reverse cipher onto a string.
Luhns:
Preforms the Luhns algorithm onto an inputted credit card number.
Fractions:
Does various operations onto inputted fractions utilizing tuples.

Conclusion:
What you learned during the lab? What new aspect of programming did you learn from the lab? Be analytical about what you learned.
I learned how to manipulate multiple strings and tuples for multiple operations.
Did pair programming help in solving the problems and completing the prelab? Did you have problems with your buddy?
No problems with my buddy, and he did help me to understand how to correctly use string manipulation.
Did you work with your buddy on the lab? What sections did you discuss? Did you and your buddy carry out a review session with each others’ code?
No, i did not work with my buddy during the lab.
Did you encounter any problems? How did you fix those problems?
I encountered problems with getting the tuples to format correctly, and found a solution after i went to the gym.
What improvements could you make?
i could make improvements on both prettiness of the code and possible better arithmetic for the code as well by using the math package rather than and made code.
