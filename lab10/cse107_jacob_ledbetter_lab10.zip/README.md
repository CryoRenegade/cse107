# The README for CSE107 Lab10

Purpose:
    Markov, make markov strings from a text file... not fun.
    Piglatin, translate a file to piglatin and write it
    navigate3, navigate2 but better
Conclusion:
    What you learned during the lab? What new aspect of programming did you learnfrom the lab? Be analytical about what you learned?
        I learned new ways of string manipulation and turtle stuffs.
    Did pair programming help in solving the problems and completing the prelab? Didyou have problems with your budy?
        No problems and having a buddy really helped out.
    Did you work with your budy on the lab? What sections did you discuss? Did youand your budy carry out a review session with each others’ code?
        Did not work with buddy on code.
    Did you encounter any problems? How did you fix those problems?
        Multiple, like with piglatin o forgot to account for single letter words. RIP my sanity.
    What improvements could you make?
        I could make many improvements, none that i want to make at this time.
