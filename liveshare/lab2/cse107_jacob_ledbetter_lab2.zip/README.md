# Readme for CSE107

Purpose:
In the file calculator.py, we use the math python package to calculate the square root, asin, acos, and atan of an input.
In the file pay.py, I use nested if statements to calculate pay for four different employee classes.
In the file polygon2.py, I use the turtle package to draw any shape using only how many sides and the desired side-length.
Conclusion:
I have learned how to use packages and nested if statements. I have previously used this inside of c++, and they are not so different, but still unusual.
The pair programming helped me to gain an edge for programming with someone of the same skill level. I had no problems with my buddy and hope to work with him again one day.
I did not work with my buddy for this lab and did it all by myself to learn the programming concepts.
I encountered a few problems with some encoding, but those were easily fixed by appending a type of data before input.
I could make the code look better in pep8, but otherwise, I have no quarrels with my code.
