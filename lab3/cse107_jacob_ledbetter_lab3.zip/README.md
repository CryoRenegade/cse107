# LAB3 ReadMe

1. From this lab, i have learned that there are places for straight up pure code... and there are places for functions in this world.

2. The pair programming helped us somewhat to understand what functions did for programming in python, but the while loop through us for a loop.

3. I did not work with my buddy on this lab.

4. I encountered the problem of encoding the fizzbuzz to include the number and possible fizzbuzzes.

5. I could definately take some time to refactor the fizzbuzz program to look more elegant, but i am happy with all the other programs. I also could take some more time to find if any other math would be better for both fizzbuzz and colatz.
