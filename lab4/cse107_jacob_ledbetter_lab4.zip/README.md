# Readme for Lab4 in CSE107

Purpose:
    Nested.py:
        Takes a nested list and runs unit tests to see if my functions work
    Statistics.py
        Takes multiple lists and runs them against statictic functions i made
    Navigation2.py
        Takes directions and putsd them into a list to be called later on
Conclusion:
    I learned how to use multiple lists in this lab.
    My buddy did help numerous times in the prelab
    I did not work with my buddy during the lab
    I encountered problems where strings could not be used to call a function in navigation2.py and the last unit test in nested.py was just plain broke.
    I could defiantely make the code pretier and more functional, but it is working as of rn.
