"""imports important package for our program"""
import turtle
"""Implement the turtle by name t1"""
t1 = turtle.Turtle()

"""Define the function of turning the turtle left"""


def left(angle):
    t1.left(angle)


"""Defines the function of turning the turtle right"""


def right(angle):
    t1.right(angle)


"""Defines the function of moving the turtle forward"""


def forward(length):
    t1.forward(length)


"""Implements main code execution"""


def main():
    """Initializes the choice variable for the while function"""
    choice = []
    nums = []
    choice.append(input("Please enter a direction:"))
    while choice[-1] != "stop":
        """Inputs user's choice"""
        nums.append(input("Please enter a number for your function"))
        choice.append(input("Please enter a direction:"))
        """Interprets user choice so that invalid choices are nullified"""
    for i in choice:
        f = i[0]
        choice.pop(0)
        n = nums[0]
        f(n)
        nums.pop(0)


"""Boilerplate stuff for main function"""
if __name__ == "__main__":
    main()
